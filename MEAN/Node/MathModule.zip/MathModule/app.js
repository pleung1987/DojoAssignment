var mathlibs = require('./mathlibs')();     //notice the extra invocation parentheses!
console.log(mathlibs);
mathlibs.add(5,6);
mathlibs.multiply(5,6);
mathlibs.square(5,6);
mathlibs.random(1,6);
