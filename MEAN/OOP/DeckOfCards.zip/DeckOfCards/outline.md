#Deck of Cards Outline

##Object constructors with properties/methods

+ **Deck**
    + Cards
    + shuffle
    + reset
    + dealCards
+ **Card**
    + value
    + suits
+ **Players**
    + name
    + hand
    + drawCard
    + discard
