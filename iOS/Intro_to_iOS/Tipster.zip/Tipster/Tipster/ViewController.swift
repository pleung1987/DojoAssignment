//
//  ViewController.swift
//  Tipster
//
//  Created by Patrick Leung on 10/3/2017.
//  Copyright © 2017 Patrick Leung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputLabel: UILabel!
    @IBOutlet weak var decimalKey: UIButton!
    //calculated numbers
    @IBOutlet weak var minPercent: UILabel!
    @IBOutlet weak var midPercent: UILabel!
    @IBOutlet weak var maxPercent: UILabel!
    @IBOutlet weak var minEach: UILabel!
    @IBOutlet weak var midEach: UILabel!
    @IBOutlet weak var maxEach: UILabel!
    @IBOutlet weak var minTip: UILabel!
    @IBOutlet weak var midTip: UILabel!
    @IBOutlet weak var maxTip: UILabel!
    //sliders
    @IBOutlet weak var tipSlider: UISlider!
    @IBOutlet weak var groupSlider: UISlider!
    @IBOutlet weak var groupSizeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        inputLabel.text = "0"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func keyPadPressed(_ sender: UIButton) {
        if inputLabel.text == "0" && sender.tag < 10 {
            inputLabel.text = String(sender.tag)
        }
        else if inputLabel.text == "0" && sender.tag == 12 {
            inputLabel.text = "0."
            sender.isEnabled = false
        }
        else if sender.tag < 10 {
            if let inputText = inputLabel.text {
                inputLabel.text = inputText + String(sender.tag)
            }
        }
        else if sender.tag == 12 {
            if let inputText = inputLabel.text {
                inputLabel.text = inputText + "."
                sender.isEnabled = false
            }
        }
        else if sender.tag == 11 {
            inputLabel.text = "0"
            decimalKey.isEnabled = true
        }
        crunchNumber()
    }

    @IBAction func tipSliderSlid(_ sender: UISlider) {
        minPercent.text = String(round(tipSlider.value)) + "%"
        midPercent.text = String(round(tipSlider.value)+5) + "%"
        maxPercent.text = String(round(tipSlider.value)+10) + "%"
        crunchNumber()
    }
    @IBAction func groupSliderSlid(_ sender: UISlider) {
        groupSizeLabel.text = String(Int(round(groupSlider.value)))
        crunchNumber()
    }
    
    func crunchNumber(){
        if let inputString = inputLabel.text {
            let input = Double(inputString)
            let tip = Double(round(tipSlider.value))
            let group = Double(round(groupSlider.value))
            let minimumTip = round((input! * (tip/100))*100)/100
            let minPerPerson = (round(((input! + minimumTip)/group)*100))/100
            let mediumTip = round((input! * ((tip + 5)/100))*100)/100
            let medPerPerson = (round(((input! + mediumTip)/group)*100))/100
            let maximumTip = round((input! * ((tip + 10)/100))*100)/100
            let maxPerPerson = (round(((input! + maximumTip)/group)*100))/100
            minTip.text = String(minimumTip)
            midTip.text = String(mediumTip)
            maxTip.text = String(maximumTip)
            minEach.text = String(minPerPerson)
            midEach.text = String(medPerPerson)
            maxEach.text = String(maxPerPerson)
        }
    }
    
}

