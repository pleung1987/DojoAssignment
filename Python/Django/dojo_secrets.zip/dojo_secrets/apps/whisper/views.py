from django.shortcuts import render, redirect
from django.contrib import messages
from django.db.models import Count
from .models import User, Secret
# Create your views here.


def index(request):
    return render(request, 'whisper/index.html')

def secrets(request):
    if 'userid' not in request.session:
        return redirect ("/")
    count_like= Secret.objects.annotate(num_like=Count('likes'))
    # print count_like[3].num_like
    context = {
        "user": User.objects.get(id=request.session['userid']),
        "secrets" : Secret.objects.all(),
    }
    return render(request, 'whisper/secrets.html', context)

def whisper(request):
    if request.method != 'POST':
        return redirect ("/secrets")
    newmessage = Secret.objects.secreteval(request.POST,request.session["userid"])
    if newmessage[0]== True:
        return redirect('/secrets')
    else:
        messages.error(request, newmessage[1])
        return redirect('/secrets')


def like(request, secret_id):
    like_valid = Secret.objects.like(request.session["userid"], secret_id)
    print "like_valid", like_valid
    return redirect('/secrets')

def delete(request):
    pass

def register(request):
    if request.method == 'GET':
        return redirect ('/')
    newuser = User.objects.validate(request.POST)
    print newuser
    if newuser[0] == False:
        for each in newuser[1]:
            messages.error(request, each) #for each error in the list, make a message for each one.
        return redirect('/')
    if newuser[0] == True:
        messages.success(request, 'Well done')
        request.session['userid'] = newuser[1].id
        return redirect('/secrets')

def login(request):
    if 'userid' in request.session:
        return redirect('/secrets')
    if request.method == 'GET':
        return redirect('/')
    else:
        user = User.objects.login(request.POST)
        print user
        if user[0] == False:
            for each in user[1]:
                messages.add_message(request, messages.INFO, each)
            return redirect('/')
        if user[0] == True:
            messages.add_message(request, messages.INFO,'Welcome, You are logged in!')
            request.session['userid'] = user[1].id
            return redirect('/secrets')

def delete(request, id):
    try:
        target= Secret.objects.get(id=id)
    except Secret.DoesNotExist:
        messages.info(request,"Message Not Found")
        return redirect('/secrets')
    target.delete()
    return redirect('/secrets')

def popular(request):
    user= User.objects.get(id=request.session["userid"])
    secrets= Secret.objects.annotate(numlikes=Count('likes')).order_by('-numlikes')
    liked= Secret.objects.filter(likes=user)
    context={
        "secrets": secrets,
        "user": user
    }
    return render(request, 'whisper/popular.html', context)

def logout(request):
    if 'userid' not in request.session:
        return redirect('/')
    print "*******"
    print request.session['userid']
    del request.session['userid']
    return redirect('/')
