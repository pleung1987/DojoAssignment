from django.shortcuts import render, redirect
from django.db.models import F, Count
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		# "leagues": League.objects.all(),
		# "teams": Team.objects.all(),
		# "players": Player.objects.all(),
		# question 1 "leagues": League.objects.filter(sport="Baseball")
		# question 2 "leagues": League.objects.filter(name__contains="Womens")
		# question 3 "leagues": League.objects.filter(sport__contains="Hockey")
		# question 4 "leagues": League.objects.exclude(sport="Football")
		# question 5 "leagues": League.objects.filter(name__contains="conference")
		# question 6 "leagues": League.objects.filter(name__contains="Atlantic")
		# question 7 "teams": Team.objects.filter(location="Dallas")
		# question 8 "teams": Team.objects.filter(team_name = "Raptors")
		# question 9 "teams": Team.objects.filter(location__contains= "City")
		# question 10 "teams": Team.objects.filter(team_name__startswith="t") #note case sensitive.
		# question 11 "teams": Team.objects.order_by("location")
		# question 12"teams": Team.objects.order_by("-team_name")
		# question 13 "players": Player.objects.filter(last_name__contains="Cooper")
		# question 14 "players": Player.objects.filter(first_name__contains="Joshua")
		# question 15 "players": Player.objects.filter(last_name__contains="Cooper").exclude(first_name__contains="Joshua")
		# question 16 "players": Player.objects.filter(first_name = "Alexander") | Player.objects.filter(first_name = "Wyatt")
		# SPORTS ORM 2
		"Atlantic": Team.objects.filter(league=League.objects.filter(name="Atlantic Soccer Conference")),
		"Penguins": Player.objects.filter(curr_team=Team.objects.filter(team_name="Penguins")),
		# "Collegiate": Player.objects.filter(curr_team=Team.objects.filter(league=League.objects.filter(name__contains="Collegiate"))),
		"Collegiate": League.objects.get(name="International Collegiate Baseball Conference"),
		"acaf": League.objects.get(name="American Conference of Amateur Football"),
		"football": League.objects.filter(sport="Football"), #because it is not specific enough, use filter
		"team_sophia": Team.objects.filter(curr_players__first_name="Sophia"), #we don't know what teams are there so we use filter to broaden
		"league_sophia": League.objects.filter(teams__curr_players__first_name__icontains="Sophia"),
		"flores":Player.objects.filter(last_name="Flores").exclude(curr_team__location="Washington", curr_team__team_name="Roughriders"),
		"samuel":Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans"),
		"vikings":Team.objects.get(location="Wichita", team_name="Vikings").all_players.all().exclude(curr_team=Team.objects.get(location="Wichita", team_name="Vikings")),
		"tigers":Team.objects.get(location="Manitoba", team_name="Tiger-Cats"),
		"Jacob": Team.objects.filter(all_players__first_name="Jacob", all_players__last_name="Gray").exclude(curr_players__first_name="Jacob", curr_players__last_name="Gray"),
		"josh_team": Team.objects.filter(league__name__contains="Atlantic Federation of Amateur Baseball"),
		"bigteam": Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gte=12),
		"num_teams": Player.objects.annotate(num_teams=Count('all_teams')).order_by("-num_teams")
	}
	print("QUERY RESULT:", context)
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
